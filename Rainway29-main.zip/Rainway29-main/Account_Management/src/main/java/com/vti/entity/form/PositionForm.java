package com.vti.entity.form;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PositionForm {
	private String name;
	private int id;
}
