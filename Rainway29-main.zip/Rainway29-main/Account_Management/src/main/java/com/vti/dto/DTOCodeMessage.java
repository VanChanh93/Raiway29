package com.vti.dto;

public class DTOCodeMessage {
	public static final int ERROR_CODE_100 = 100;
	public static final int ERROR_CODE_101 = 101;
	public static final int ERROR_CODE_102 = 102;
	public static final int ERROR_CODE_103 = 103;
	

	public static final String MSG_CODE_100 = "Lỗi không xác định";
	public static final String MSG_CODE_101 = "Lỗi xác thực email";
	public static final String MSG_CODE_102 = "Lỗi validate data";
	public static final String MSG_CODE_103 = "Không tìm thấy AccountID hợp lệ";
	
	
	
	public static final int SUCCESS_CODE_200 = 200;
	
	public static final String MSG_CODE_200 = "Thành công";
	
}
