package com.vti.entity.filter;

import lombok.NoArgsConstructor;

import lombok.Data;

@Data
@NoArgsConstructor
public class PositionFilter {
	private String positionName;
}
