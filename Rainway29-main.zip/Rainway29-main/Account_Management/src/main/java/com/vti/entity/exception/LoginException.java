package com.vti.entity.exception;

public class LoginException extends Exception{
public LoginException(String message) {
	super(message);
}
}
