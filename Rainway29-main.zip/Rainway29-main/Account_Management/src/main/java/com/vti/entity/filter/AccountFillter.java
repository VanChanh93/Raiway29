package com.vti.entity.filter;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AccountFillter {

	private String userName;
	private String email;

}
