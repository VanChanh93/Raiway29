package frontend;

import entity.QLCB;

public class Program {
	public static void main(String[] args) {
		QLCB qlcb = new QLCB();
	}
}
