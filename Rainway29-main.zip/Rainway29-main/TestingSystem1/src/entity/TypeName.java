package entity;
	public enum TypeName {
		ESSAY, MULTIPLE_CHOICE;
	}
