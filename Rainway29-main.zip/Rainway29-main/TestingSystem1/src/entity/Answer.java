package entity;

public class Answer {
	int id;
	String content;
	Question question;
	Boolean isCorrect;
}
