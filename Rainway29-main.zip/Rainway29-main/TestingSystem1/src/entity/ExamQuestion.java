package entity;

public class ExamQuestion {
	Exam exam;
	Question question;
}
