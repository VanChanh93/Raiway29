package entity;

import java.time.LocalDate;

public class GroupAccount {
	Group idGroup;
	Account idAccount;
	LocalDate joinDate;
}
