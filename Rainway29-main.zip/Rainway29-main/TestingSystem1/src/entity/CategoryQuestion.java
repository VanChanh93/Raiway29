package entity;

public class CategoryQuestion {
	int id;
	String name;
}
