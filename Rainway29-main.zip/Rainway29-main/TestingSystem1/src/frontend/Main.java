package frontend;

import entity.Department;

public class Main {
public static void main(String[] args) {
	Department department = new Department();
	department.setId(0);
}
}
