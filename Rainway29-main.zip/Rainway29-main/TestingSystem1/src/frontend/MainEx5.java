package frontend;

import testingsystem.Exercise5Test2;

public class MainEx5 {
	public static void main(String[] args) {
		Exercise5Test2 exercise5Test2 = new Exercise5Test2();
		exercise5Test2.question11();
	}
}
