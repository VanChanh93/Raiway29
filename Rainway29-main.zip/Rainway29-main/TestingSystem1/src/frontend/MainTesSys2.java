package frontend;

import testingsystem.TestingSystem2;

public class MainTesSys2 {

	public static void main(String[] args) {
		TestingSystem2 testingSystem2 = new TestingSystem2();
		testingSystem2.question5();
	}
}
