package frontend;

import testingsystem.TestingSystem3;

public class MainTesSys3 {
	public static void main(String[] args) {
		TestingSystem3 tes3 = new TestingSystem3();
		tes3.Test3question12d();
	}
}
