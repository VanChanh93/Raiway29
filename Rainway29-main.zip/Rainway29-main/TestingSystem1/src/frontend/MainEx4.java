package frontend;

import testingsystem.Exercise4Test2;

public class MainEx4 {
	public static void main(String[] args) {
		Exercise4Test2 exercisr4Test2 = new Exercise4Test2();
		exercisr4Test2.question7();
	}
}
