package frontend;

import backend.Exercise1;
import backend.Exercise1_Question2;

public class Program {
	public static void main(String[] args) {
//		Exercise1 exercise1 = new Exercise1();
//		exercise1.question1();
		Exercise1_Question2 exercise1_Question2 = new Exercise1_Question2();
		exercise1_Question2.question2();

	}
}
