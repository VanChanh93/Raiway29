package entity;

public interface INews {
	public void display();

	public float calculate();
}
