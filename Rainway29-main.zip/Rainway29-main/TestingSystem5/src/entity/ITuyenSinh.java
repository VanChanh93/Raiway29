package entity;

public interface ITuyenSinh {
	public void addNew();

	public void showInfo();

	public void findById(int id);
}
