package frontend;

import testingsystem.TestingSystem1;

public class Main {

	public static void main(String[] args) {
		TestingSystem1 testingSystem1 = new TestingSystem1();
		testingSystem1.question14c();
	}
}
