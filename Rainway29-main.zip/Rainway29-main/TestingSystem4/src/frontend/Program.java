package frontend;

import backend.Exercise6;

public class Program {
	public static void main(String[] args) {
		Exercise6 exercise6 = new Exercise6();
		exercise6.question2();
	}
}
