package frontend;

import entity.QuanLySach;

public class Program {
	public static void main(String[] args) {
		QuanLySach quanLySach = new QuanLySach();
	}
}
