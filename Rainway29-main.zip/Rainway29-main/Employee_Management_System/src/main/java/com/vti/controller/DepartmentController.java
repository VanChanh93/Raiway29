package com.vti.controller;

public class DepartmentController {

}
