package com.vti.service;

public class DepartmentService {

}
