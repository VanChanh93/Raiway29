package com.vti.datalayer.jpa;

public interface PositionRepository {

}
