package com.vti.service;

public interface IDepartmentService {

}
