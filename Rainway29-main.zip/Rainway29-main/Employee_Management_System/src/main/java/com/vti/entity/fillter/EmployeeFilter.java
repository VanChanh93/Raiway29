package com.vti.entity.fillter;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EmployeeFilter {
	private String username;
	private String fullname;
}
